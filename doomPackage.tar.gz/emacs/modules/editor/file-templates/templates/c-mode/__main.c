# -*- mode: snippet -*-
# group: file templates
# contributor: Lorenzo Ravaglia
# --
#include <stdio.h>

int main(int argc, char *argv[]) {
    $0

    return 0;
}