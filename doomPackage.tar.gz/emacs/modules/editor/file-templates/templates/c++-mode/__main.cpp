# -*- mode: snippet -*-
# group: file templates
# contributor: Henrik Lissner
# --
#include <iostream>

auto main(int argc, char *argv[]) -> int {
    $0

    return 0;
}
