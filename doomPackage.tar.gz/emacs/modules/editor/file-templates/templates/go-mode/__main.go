package ${1:main}

import (
   "fmt"
)

func main() {
     $0
}