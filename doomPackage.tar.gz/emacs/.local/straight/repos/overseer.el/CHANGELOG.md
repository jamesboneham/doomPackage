# Changelog

## v0.3.0 (2015-06-08)

### Changes

  * Enable Overseer mode just in emacs lisp test files `-test.el`.

### Enhancements

  * Add keybinding for `overseer-test-file` which prompts for test file running.

## v0.2.0 (2015-01-20)

### Enhancements

  * No need to establish the root directory separate
  * Remove error link options
  * Error handling don't need be made inside the function
  * Refine codebase

### Bugfixes

  * Fix typo in function call (Nicolas Lamirault)

### Enhancements

  * Implement `overseer-test-file` function.

## v0.1.0 (2014-12-30)
