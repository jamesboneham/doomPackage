---
name: Performance issue
about: Report a performance problem or regression
title: ''
---

### Description

<!--
What is the issue ? Regression ?
When does markdown-mode become slow ? syntax, file size etc
-->

## Software Versions

<!--
Use M-x markdown-show-version and M-x emacs-version to determine the
Markdown Mode and Emacs version numbers.

Examples:

- Markdown Mode: From Git on 2017-10-17, 2.8-dev, or 2.7
- Emacs: 30.1
- OS: macOS Sequoia
-->

- Markdown Mode:
- Emacs:
- OS:
