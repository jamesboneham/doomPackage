Zettel files are written in Markdown

