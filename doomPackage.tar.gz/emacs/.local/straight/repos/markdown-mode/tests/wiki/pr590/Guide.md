**Basics**: A neuron notebook is just a directory of [[Zettel Markdown]] files
