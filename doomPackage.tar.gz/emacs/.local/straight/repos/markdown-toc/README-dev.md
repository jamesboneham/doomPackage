# Enter shell

```
$ make activate
```

*Note*: This requires nix with the flake option activated.

# Hack

```
$ emacs markdown-toc.el
```

# Test

Adapt the tests and run them

```
make test
```
