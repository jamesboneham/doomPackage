# Highlight quoted minor mode for Emacs

## Activate it through a hook

```
(add-hook 'emacs-lisp-mode-hook 'highlight-quoted-mode)
```
