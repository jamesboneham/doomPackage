#!perl
use strict;
use warnings;

print "I love Common Lisp\n";

#
#  Local Variables:
#  quickrun-option-outputter: null
#  End:
#
