#!/bin/bash

function helloworld () {
    printf "Hello Bash $1\n"
}

helloworld "quickrun"
