#!perl
use strict;
use warnings;

print "I love Perl too\n";

#
#  Local Variables:
#  quickrun-option-outputter: variable:test-variable
#  End:
#
