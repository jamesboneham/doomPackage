<?php
echo "Hello PHP\n";
?>
