function hello_world(name)
    print(string("hello ", name, "\n"))
end

hello_world("quickrun")
