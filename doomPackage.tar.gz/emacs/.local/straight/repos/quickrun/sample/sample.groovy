def helloworld() {
    println("Hello Groovy")
}

helloworld()
