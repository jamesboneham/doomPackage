package main

import "fmt"

func main() {
	fmt.Printf("hello, Go language\n")
}
