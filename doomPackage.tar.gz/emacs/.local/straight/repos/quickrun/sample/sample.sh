#!/bin/sh
printf "Hello /bin/sh\n"
