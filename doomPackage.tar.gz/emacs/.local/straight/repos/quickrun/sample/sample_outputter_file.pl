#!perl
use strict;
use warnings;

print "I love emacs\n";
print "You love emacs\n";
print "We love emacs\n";

#
#  Local Variables:
#  quickrun-option-outputter: file:qr_test.txt
#  End:
#
