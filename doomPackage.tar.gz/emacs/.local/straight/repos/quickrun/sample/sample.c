#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("hello C\n");
    return 0;
}
