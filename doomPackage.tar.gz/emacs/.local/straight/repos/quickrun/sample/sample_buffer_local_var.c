#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[])
{
    printf("cos(3.14) = %g\n", cos(3.14));
    return 0;
}

/*
  Local Variables:
  quickrun-option-cmdopt: "-lm"
  End:
*/
