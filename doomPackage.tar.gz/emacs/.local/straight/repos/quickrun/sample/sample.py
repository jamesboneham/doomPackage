def helloworld (arg):
    print("Hello Python " + arg)

helloworld("quickrun.el")
