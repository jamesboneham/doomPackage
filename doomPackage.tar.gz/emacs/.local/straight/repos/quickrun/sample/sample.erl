-module(demo).
-export([main/1]).

main(_Args) ->
  io:format("Hello, Erlang\n", []).
