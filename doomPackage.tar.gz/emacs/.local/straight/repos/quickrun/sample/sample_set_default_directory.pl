#!perl
use strict;
use warnings;

print "hello\n";

#
#  Local Variables:
#  quickrun-option-cmd-alist: ((:command . "sh")
#                              (:exec    . ("sh -c 'ls -l'"))
#                              (:default-directory . "/tmp"))
#  End:
#
