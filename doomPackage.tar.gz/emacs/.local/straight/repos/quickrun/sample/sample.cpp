#include <iostream>

int main(int argc, char *argv[])
{
    std::cout << "hello C++" << std::endl;
    return 0;
}
