func helloWorld(name : String) -> String {
    return "Hello \(name)"
}

print(helloWorld("quickrun"))
