use strict;
use warnings;

print "hello world\n";
