#!perl
use strict;
use warnings;

print "I love Emacs and Vim\n";
print "You love Emacs and Vim\n";
print "We love Emacs and emacs\n";

#
#  Local Variables:
#  quickrun-option-outputter: (multi . (buffer:*multi1* file:multi.txt variable:multi-var))
#  End:
#
