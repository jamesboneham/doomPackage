(defn helloworld []
  (println "Hello Clojure"))

(helloworld)
