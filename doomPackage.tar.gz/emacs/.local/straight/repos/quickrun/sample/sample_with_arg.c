#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("hello world %s %s\n", argv[1], argv[2]);
    return 0;
}
