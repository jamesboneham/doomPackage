class HelloWorld {
  say(name) {
    print('Hello Dart, $name');
  }
}

main() {
  var hello = new HelloWorld();
  hello.say("quickrun.el!");
}
