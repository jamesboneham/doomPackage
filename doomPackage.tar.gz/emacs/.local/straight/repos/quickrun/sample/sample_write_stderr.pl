#!/usr/bin/env perl
use strict;
use warnings;

use Data::Dumper;

die Dumper({ name => 'Vim', age => 30, hobby => 'driving' });
