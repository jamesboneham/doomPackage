#!/usr/bin/env ruby
# -*- coding: utf-8 -*-

puts "hello Ruby"
