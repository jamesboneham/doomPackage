#!perl
use strict;
use warnings;

my $name = shift;
print "my name is $name\n";
