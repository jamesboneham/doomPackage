function helloworld (arg) {
    print(arg + "\n");
}

helloworld("Hello jrunscript");
