function helloWorld()
   print("Hello, Lua")
end

helloWorld()
