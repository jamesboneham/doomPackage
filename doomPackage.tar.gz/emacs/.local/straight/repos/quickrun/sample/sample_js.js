(function (arg) {
    print(arg);
}("Hello World"));
