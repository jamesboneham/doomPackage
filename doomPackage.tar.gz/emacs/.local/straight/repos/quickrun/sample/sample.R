
print("Here is a plot generated with R:")
X11()
plot(1:10, pch=1:10)
Sys.sleep(2)
print("Bye!")
