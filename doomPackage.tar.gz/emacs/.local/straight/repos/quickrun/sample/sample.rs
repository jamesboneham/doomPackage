use std;

fn main() {
    std::io::println("Hello world in Rust");
}
