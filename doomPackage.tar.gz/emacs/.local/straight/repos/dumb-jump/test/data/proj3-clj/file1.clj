
(defn blah
  (print "hello"))

(defn- foo*
  (print "hello"))
