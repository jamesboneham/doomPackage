int main(int argc, char **argv) {
  IAmOnlyHere iaoh;
}

// Place after just to have a test with a ":diff < 0".
class IAmOnlyHere {
};
