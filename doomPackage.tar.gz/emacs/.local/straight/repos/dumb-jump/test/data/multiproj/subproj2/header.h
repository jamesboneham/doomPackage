#ifndef TEST_DATA_MULTIPROJ_SUBPROJ2_HEADER_H
#define TEST_DATA_MULTIPROJ_SUBPROJ2_HEADER_H

class Awesome {
public:
  int magic() { return 42; }
};

#endif // TEST_DATA_MULTIPROJ_SUBPROJ2_HEADER_H
