#ifndef PROJ1_SRC_CPP_EXTERNAL_H
#define PROJ1_SRC_CPP_EXTERNAL_H

class ExternalThing {
public:
  void foo();
};

#endif // PROJ1_SRC_CPP_EXTERNAL_H
