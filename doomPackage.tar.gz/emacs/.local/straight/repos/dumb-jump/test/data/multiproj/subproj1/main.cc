#include "../subproj2/header.h"

int main(int argc, char **argv) {
  return Awesome::magic();
}
