(defn blah?
  (print "hello2"))

(deftask foo []
  (print "hello2"))
