// comment begin
// hello
// comment end

console.log('hello');
function bye() {
  throw new Error('bye');
}
bye();
